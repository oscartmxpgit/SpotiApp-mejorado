import { SpotifyAPIService } from './../shared/services/spotify-api.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  nuevosAlbunes: any[]=[];

  constructor(private _spotify: SpotifyAPIService ) {
    this._spotify.getNewReleases()
    .subscribe((data:any)=>{
      this.nuevosAlbunes=data.albums.items;

    });

   }

  ngOnInit(): void {
  }

}
