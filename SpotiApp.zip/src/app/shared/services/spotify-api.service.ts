import { TestBed } from '@angular/core/testing';
import { HttpClient, HttpHeaders } from '@angular/common/http';


import { Inject, Injectable } from '@angular/core';

@Injectable({
  providedIn:'root'
})

export class SpotifyAPIService{


  token='BQBX5_CUerdvB1579_zwAqfsWezWAFkPoGfTgJ19CxHH5R2PrTy2PoutSZGxigvcacgj7F24kkoW_BARycI';

  headers=new HttpHeaders({
    'authorization': 'Bearer ' + this.token
  });

  constructor(private http:HttpClient){
    console.log('servicio spotify listo');
  }

  getNewReleases(){
    const url='https://api.spotify.com/v1/browse/new-releases?limit=21';

    const headers=this.headers;
    return (this.http.get(url,{headers}))
  }

  getArtistInfo(id: string){
    const url2='https://api.spotify.com/v1/artists/'+id;
    const headers=this.headers;

    return (this.http.get(url2,{headers}))
  }

  getsongs(id: string){
    const url2='https://api.spotify.com/v1/artists/'+id+'/top-tracks?market=us';
    const headers=this.headers;
    return (this.http.get(url2,{headers}))
  }

  search(artist: string){
    //https://api.spotify.com/v1/search?q=Metallica&type=artist
    const url2='https://api.spotify.com/v1/search?q='+artist+'&type=artist';
    const headers=this.headers;
    return (this.http.get(url2,{headers}))
  }
}