import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SpotifyAPIService } from './../shared/services/spotify-api.service';

@Component({
  selector: 'app-busq-res',
  templateUrl: './busq-res.component.html',
  styleUrls: ['./busq-res.component.scss']
})
export class BusqResComponent implements OnInit {
  public artistName: any;
  public resultados: any;

  constructor(protected _spotify: SpotifyAPIService,
    protected route: ActivatedRoute)
    {
      this.route.params.subscribe(parameters => {
        this.artistName = parameters['nombre'];
   });

      this._spotify.search(this.artistName)
      .subscribe((data:any)=>{
        this.resultados=data;

     });
  }

  ngOnInit(): void {
  }

}
